import math
import random
import pygame
from pygame import mixer
#initializing pygame
pygame.init()
#creating the screen
screen= pygame.display.set_mode((800,600))

#Background
background=pygame.image.load('background.jpg')
#Background sound
mixer.music.load('backgroundSound.mp3')
mixer.music.play(-1)

#title and logo
pygame.display.set_caption("Expecto Patronum")
icon=pygame.image.load('player.png')
pygame.display.set_icon(icon)

#player
playerImg= pygame.image.load("player.png")
playerImg=pygame.transform.scale(playerImg,(100,100))
playerX=370
playerY=480
playerX_changed=0
#enemy

enemyImg=[]
enemyX=[]
enemyY=[]
enemyX_changed=[]
enemyY_changed=[]
num_of_enemies= 4
#enemyImg=pygame.transform.scale(enemyImg,(100,100))
for i in range(num_of_enemies):
    enemyImg.append(pygame.image.load("enemy1.png"))
    enemyX.append(random.randint(0,700))
    enemyY.append(random.randint(50,150))
    enemyX_changed.append(4)
    enemyY_changed.append(40)

#charm
charmImg= pygame.image.load("lightCharm.png")
charmImg=pygame.transform.scale(charmImg,(50,50))
charmX=0
charmY=480
charmX_changed=0
charmY_changed=10
charm_state="ready"

#Font
score_value=0
font=pygame.font.Font("freesansbold.ttf",32)
textX=10
textY=10

#Game Over Text
over_font=pygame.font.Font("freesansbold.ttf",64)

def show_score(x,y):
    score=font.render("Score: "+str(score_value),True,(255,255,255))
    screen.blit(score, (x, y))

def game_over_text():
    over_text= over_font.render("GAME OVER", True, (255, 255, 255))
    screen.blit(over_text, (200,250))

def player(x,y):
    screen.blit(playerImg,(x,y))

def enemy(x,y,i):
    screen.blit(enemyImg[i],(x,y))

def spell_charm(x,y):
    global charm_state
    charm_state = "spell"
    screen.blit(charmImg,(x+16,y+10))

def isCollision(enemyX,enemyY,charmX,charmY):
    distance=math.sqrt((math.pow(enemyX-charmX,2))+(math.pow(enemyY-charmY,2)))
    if distance<27:
        return True
    else:
        return False
#game loop
run= True
while run:
    # RGB= Red, Green, Blue
    screen.fill((0, 0, 128))
    #background image
    screen.blit(background,(0,0))
    #playerY -= 0.1
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        #if keystroke is pressed check whether it's right or left
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                playerX_changed= -5
            if event.key==pygame.K_RIGHT:
                playerX_changed= 5
            if event.key==pygame.K_SPACE:
                if charm_state=="ready":
                    charm_sound= mixer.Sound('laser2.wav')
                    charm_sound.play()
                    charmX=playerX
                    spell_charm(playerX,charmY)

        if event.type==pygame.KEYUP:
            if event.key==pygame.K_LEFT or event.key==pygame.K_RIGHT:
                playerX_changed= 0

    #checking for boundaries
    playerX+= playerX_changed
    if playerX<=0:
        playerX=0
    elif playerX>=700:
        playerX=700

    for i in range(num_of_enemies):
        #Game Over
        if enemyY[i]>410:
            for j in range(num_of_enemies):
                enemyY[j]=2000
            game_over_text()
            break
        enemyX[i]+= enemyX_changed[i]
        if enemyX[i]<=0:
            enemyX_changed[i]=3
            enemyY[i]+= enemyY_changed[i]
        elif enemyX[i]>=700:
            enemyX_changed[i]=-3
            enemyY[i] += enemyY_changed[i]

        # Collision
        collision = isCollision(enemyX[i], enemyY[i], charmX, charmY)
        if collision:
            explosion_sound = mixer.Sound('laser1.wav')
            explosion_sound.play()
            charmY = 480
            charm_state = "ready"
            score_value += 1
            print(score_value)
            enemyX[i] = random.randint(0, 700)
            enemyY[i] = random.randint(50, 150)

        enemy(enemyX[i], enemyY[i],i)

    #charm movement
    if charmY<=0:
        charmY=480
        charm_state="ready"

    if charm_state=="spell":
        spell_charm(charmX,charmY)
        charmY-=charmY_changed


 
    player(playerX,playerY)
    show_score(textX,textY)
    pygame.display.update()
